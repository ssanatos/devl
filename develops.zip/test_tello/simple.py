from djitellopy import Tello

tello = Tello()

tello.connect()

tello.takeoff()

tello.land()

pass