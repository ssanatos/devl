import os

os.getcwd()