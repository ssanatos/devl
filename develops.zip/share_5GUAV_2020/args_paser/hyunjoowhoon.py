pass

# 3개의 값을 갖는다
# 여러분 마음
# -first 49 -second 30 -third 0
# 곱샘과 나눗샘 --> function 처리
# basic sentence 틀에서 벗어나지 말것
# exception 처리 --> 중간 중단 없음.

# 최종 결과는 print()
