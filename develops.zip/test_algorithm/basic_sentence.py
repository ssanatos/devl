def func():
    pass
    return

if __name__ == '__main__':
   try:
      pass
   except Exception as e:
      pass

