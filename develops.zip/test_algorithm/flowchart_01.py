b=20
c=10

def fun(b,c):
    a = b + c
    return a

a = fun(b,c)

print(a)