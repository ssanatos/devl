a = 10
b = 20

# c = a + b
# d = a - b
# e = a * b
# f = a / b
def fun(a,b):
    c = a + b
    d = a - b
    e = a * b
    f = a / b
    return c,d,e,f

print(fun(a,b))